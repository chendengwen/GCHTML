'use strict'
module.exports = {
  NODE_ENV: '"production"',
  mode: 'production'
  // API_ROOT:'"/b"'
}
